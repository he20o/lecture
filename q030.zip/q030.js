var userRpc = "";
while(true){
    userRpc = prompt("가위바위보!!!!");
    if(userRpc == "가위"||userRpc == "바위"||userRpc=="보"){
        break;
    }else{
        alert("다시");
    }
}


var comRpc = Math.floor(Math.random()*3+1);
if(comRpc == 1){
    comRpc = "가위";
}
if(comRpc == 2){
    comRpc = "바위";
}
if(comRpc == 3){
    comRpc = "보";
}

dw("유저:"+userRpc);
br();
dw("컴:"+comRpc);
br();

var winDrawlose = "";
switch(userRpc){
    case"가위":
        switch(comRpc){
            case"가위":
                winDrawlose = "비겼다";
                break;
            case"바위":
                winDrawlose = "졌다";
                break;
            case"보":
                winDrawlose = "이겼다";
                break;
        }
        break;
    case"바위":
        switch(comRpc){
            case"가위":
                winDrawlose = "이겼다";
                break;
            case"바위":
                winDrawlose = "비겼다";
                break;
            case"보":
                winDrawlose = "졌다";
                break;
        }
        break;
    case"보":
        switch(comRpc){
            case"가위":
                winDrawlose = "졌다";
                break;
            case"바위":
                winDrawlose = "이겼다";
                break;
            case"보":
                winDrawlose = "비겼다";
                break;
        }
        break;


}

dw(winDrawlose);