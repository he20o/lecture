var userRpc = "";
var comRpc = "";

var rpcinputText;

window.onload = function () {
    rpcinputText = document.getElementById("rpc_input_text");
}

function rpcinputButtonClick() {
    while (true) {
        // userRpc = prompt("가위, 바위, 보!!!!!!!");
        userRpc = rpcinputText.value;
        if (userRpc == "가위" || userRpc == "바위" || userRpc == "보") {
            break;
        } else {
            alert("다시");
        }
    }
    comRpc = Math.floor(Math.random() * 3 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    }
    if (comRpc == 2) {
        comRpc = "바위";
    }
    if (comRpc == 3) {
        comRpc = "보";
    }

    dw("유저 : " + userRpc);
    br();
    dw("컴 :" + comRpc);
    br();
    var winDrowlose = "";

    switch (userRpc) {
        case "가위":
            switch (comRpc) {
                case "가위":
                    winDrowlose = "비겼다";
                    break;
                case "바위":
                    winDrowlose = "졌다";
                    break;
                case "보":
                    winDrowlose = "이겼다";
                    break;
            }
            break;
        case "바위":
            switch (comRpc) {
                case "가위":
                    winDrowlose = "이겼다";
                    break;
                case "바위":
                    winDrowlose = "비겼다";
                    break;
                case "보":
                    winDrowlose = "졌다";
                    break;
            }
            break;
        case "보":
            switch (comRpc) {
                case "가위":
                    winDrowlose = "졌다";
                    break;
                case "바위":
                    winDrowlose = "이겼다";
                    break;
                case "보":
                    winDrowlose = "비겼다";
                    break;
            }
            break;
    }
    dw(winDrowlose);

}


