// 가위바위보 게임 v5

var userRpc = "";
var comRpc = "";

var rpcInputText;
var rpcResultScreen;

var resultString = "";

var divRpcImgUser;
var divRpcImgCom;

window.onload = function () {
    rpcInputText = document.getElementById("rpc_input_text");
    rpcResultScreen = document.getElementById("rpc_result_screen");
    divRpcImgUser = document.getElementById("rpc_user");
    divRpcImgCom = document.getElementById("rpc_com");
}

function rpcInputButtonClick() {
    while (true) {
        userRpc = rpcInputText.value;
        if (userRpc == "가위" || userRpc == "바위" || userRpc == "보") {
            break;
        } else {
            alert("다시다시다시");
        }
    }
    comRpc = Math.floor(Math.random() * 3 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    }
    if (comRpc == 2) {
        comRpc = "바위";
    }
    if (comRpc == 3) {
        comRpc = "보";
    }

    resultString = "유저 :" + userRpc;
    resultString = resultString + "\n";
    resultString = resultString + "컴 :" + comRpc;
    resultString += "\n";

    switch (userRpc) {
        case "가위":
            divRpcImgUser.innerHTML = "<img src='scissors.png'>"
            break;
        case "바위":
            divRpcImgUser.innerHTML = "<img src='rock.png'>"
            break;
        case "보":
            divRpcImgUser.innerHTML = "<img src='paper.png'>"
            break;

    }
    switch (comRpc) {
        case "가위":
            divRpcImgCom.innerHTML = "<img src='c_scissor.png'>"
            break;
        case "바위":
            divRpcImgCom.innerHTML = "<img src='c_rock.png'>"
            break;
        case "보":
            divRpcImgCom.innerHTML = "<img src='c_paper.png'>"
            break;

    }

    var winDrawLose = "";
    switch (userRpc) {
        case "가위":
            switch (comRpc) {
                case "가위":
                    winDrawLose = "비겼다";
                    break;
                case "바위":
                    winDrawLose = "졌다";
                    break;
                case "보":
                    winDrawLose = "이겼다";
                    break;
            }
            break;
        case "바위":
            switch (comRpc) {
                case "가위":
                    winDrawLose = "이겼다";
                    break;
                case "바위":
                    winDrawLose = "비겼다";
                    break;
                case "보":
                    winDrawLose = "졌다";
                    break;
            }
            break;
        case "보":
            switch (comRpc) {
                case "가위":
                    winDrawLose = "졌다";
                    break;
                case "바위":
                    winDrawLose = "이겼다";
                    break;
                case "보":
                    winDrawLose = "비겼다";
                    break;
            }
            break;
    }

    resultString = resultString + "결과 :" + winDrawLose;
    rpcResultScreen.value = resultString;

}




















